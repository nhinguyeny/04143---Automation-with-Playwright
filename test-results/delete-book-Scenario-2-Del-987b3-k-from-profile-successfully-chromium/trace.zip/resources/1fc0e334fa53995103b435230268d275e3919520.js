(function() {
	(document.createElement('IMG')).src = 'https://ssp-sync.criteo.com/user-sync/redirect?profile=342&gdpr_consent=&gdpr=0&gpp=&gpp_sid=&redir=https%3A%2F%2Fcm.mgid.com%2Fm%3Fcdsp%3D834177%26c%3D%24%7BCRITEO_USER_ID%7D';
	(document.createElement('IMG')).src = 'https://prebid.a-mo.net/cchain/0?gdpr=0&gdpr_consent=&us_privacy=&cb=https%3A//cm.mgid.com/m%3Fcdsp%3D779131%26c%3D';
	(document.createElement('IMG')).src = 'https://match.360yield.com/match?external_user_id=papSQd5K1eHj&publisher_dsp_id=489&dsp_callback=1&&gdpr=0&gdpr_consent=&r=https%3A%2F%2Fcm.mgid.com%2Fm%3Fcdsp%3D834124%26c%3D%7BPUB_USER_ID%7D';
	(document.createElement('IMG')).src = 'https://ssbsync.smartadserver.com/api/sync?callerId=155&gdpr=0&gdpr_consent=&url=https%3A%2F%2Fcm.mgid.com%2Fm%3Fcdsp%3D834126%26c%3D%5Bsas_sync_pid%5D%26nwid%3D4577';
	(document.createElement('IMG')).src = 'https://ib.adnxs.com/getuid?https://cm.mgid.com/m?cdsp=834104&c=$UID';
	(document.createElement('IMG')).src = 'https://creativecdn.com/cm-notify?pi=mgid&gdpr=0&gdpr_consent=&us_privacy=';
	var d834098 = document.createElement('div');d834098.innerHTML="<iframe src=\"https://onetag-sys.com/usync/?pubId=7cd9d7c7c13ff36&sync_id=papSQd5K1eHj&gdpr=0&gdpr_consent=&us_privacy=\" style=\"display: none;\"></iframe>";document.body.appendChild(d834098);
})()
